package com.ironhack.educacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
